package json.com.inclass06;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Created by Durga Abayakumar on 2/19/2018.
 */

public class GetNewsAsync extends AsyncTask<String,Void,ArrayList<News>> {

    ArrayList<News> keyNews = new ArrayList<>();

    IKeywords keys;
    public GetNewsAsync(IKeywords newKeys){
        keys = newKeys;
    }

    @Override
    protected ArrayList<News> doInBackground(String... strings) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        StringBuilder sb = new StringBuilder();
        String result;
        try {
            Log.d("demo", "doInBackground: ");
            URL url = new URL(strings[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){//read result only if the response is ok.
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = "";
                while((line = reader.readLine()) != null){
                    sb.append(line);
                }
                result = sb.toString();
                Log.d("demo", "result is: " + result);
                JSONObject root = new JSONObject(result);
                JSONArray news = root.getJSONArray("articles");//root element
                for(int i=0;i<news.length();i++){
                    JSONObject source = news.getJSONObject(i);
                    News n = new News();
                    JSONObject s = source.getJSONObject("source");
                    String id = s.getString("id");
                    Log.d("demo", "id value is : " + id);
                    if(id==null){
                        n.setId("");
                    }else{
                        n.setId(id);
                    }
                    String name = s.getString("name");
                    if(name==null){
                        n.setName("");
                    }else{
                        n.setName(name);
                    }
                    n.setAuthor(source.getString("author"));
                    String title = source.getString("title");
                    if(title==null){
                        n.setTitle("");
                    }else{
                        n.setTitle(title);
                    }
                    String desc = source.getString("description");
                    if(desc==null){
                        n.setDescription("");
                    }else{
                        n.setDescription(desc);
                    }

                    n.setUrl(source.getString("url"));
                    n.setUrlToImage(source.getString("urlToImage"));
                    n.setPublishedAt(source.getString("publishedAt"));
                    keyNews.add(n);
                }
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } finally{
            if(connection!=null){
                connection.disconnect();
            }
            if(reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
//        for(String str:keyNews){
            Log.d("demo", "keywork size is: " +keyNews.size() );
//        }
        return keyNews;
    }

    @Override
    protected void onPostExecute(ArrayList<News> strings) {
        keys.handleKeywords(strings);
    }

    public static interface IKeywords{
        public void handleKeywords(ArrayList<News> data);
    }
}
