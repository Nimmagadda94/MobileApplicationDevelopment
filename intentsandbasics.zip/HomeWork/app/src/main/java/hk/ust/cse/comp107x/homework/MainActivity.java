//VASANTHI NIMMAGADDA (800987920)
//DURGA ABHAYAKUMAR

package hk.ust.cse.comp107x.homework;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Activity activity;
    Double tipvalue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.icon);

        activity = this;

        final MainActivity cal = new MainActivity();
        final TextView percent = (TextView) findViewById(R.id.textView8);
        final SeekBar sbvalue = (SeekBar) findViewById(R.id.seekBar);
        final EditText billvalue = (EditText) findViewById(R.id.editText);
        final RadioGroup grp = (RadioGroup) findViewById(R.id.radioGroup);
        final TextView tip = (TextView) findViewById(R.id.textView5);
        final TextView total = (TextView) findViewById(R.id.textView7);
        final Button exit = (Button) findViewById(R.id.button);

        percent.setText(String.valueOf(sbvalue.getProgress())+"%");

        sbvalue.setEnabled(false);

        billvalue.addTextChangedListener(new DecimalFilter(billvalue, activity));

        billvalue.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    if (billvalue.getText().toString()==null||billvalue.getText().length()==0){
                        Toast.makeText(getApplicationContext(), "Please Enter the Total Bill", Toast.LENGTH_SHORT).show();
                        billvalue.setError("Enter Bill Total");
                    }
                    else {
                        RadioButton btn = (RadioButton) findViewById(grp.getCheckedRadioButtonId());
                        switch (btn.getText().toString()) {
                            case "10%":
                                tipvalue = Integer.parseInt(billvalue.getText().toString()) * 0.10;
                                break;
                            case "15%":
                                tipvalue = Integer.parseInt(billvalue.getText().toString()) * 0.15;
                                break;
                            case "18%":
                                tipvalue = Integer.parseInt(billvalue.getText().toString()) * 0.18;
                                break;
                            case "Custom":
                                sbvalue.setEnabled(true);
                                tipvalue = (sbvalue.getProgress() / 100.0f) * Double.parseDouble(billvalue.getText().toString());
                                break;
                        }
                        tip.setText(String.format( "%.2f", tipvalue ));
                        Double totalvalue = tipvalue + Integer.parseInt(billvalue.getText().toString());
                        total.setText(String.format( "%.2f", totalvalue ));
                    }
                }
                else{
                    if (billvalue.getText().toString()==null||billvalue.getText().length()==0){
                        Toast.makeText(getApplicationContext(), "Please Enter the Total Bill", Toast.LENGTH_SHORT).show();
                        billvalue.setError("Enter Bill Total");
                    }
                }
            }
        });

        grp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                sbvalue.setEnabled(false);
                if (billvalue.getText().toString()==null||billvalue.getText().length()==0){
                    Toast.makeText(getApplicationContext(), "Please Enter the Total Bill", Toast.LENGTH_SHORT).show();
                    billvalue.setError("Field cannot be left blank.");
                }
                else{
                    //cal.calculate();
                    RadioButton btn = (RadioButton) findViewById(grp.getCheckedRadioButtonId());
                    switch (btn.getText().toString()){
                        case "10%":
                            tipvalue = Integer.parseInt(billvalue.getText().toString()) * 0.10;
                            break;
                        case "15%":
                            tipvalue = Integer.parseInt(billvalue.getText().toString()) * 0.15;
                            break;
                        case "18%":
                            tipvalue = Integer.parseInt(billvalue.getText().toString()) * 0.18;
                            break;
                        case "Custom":
                            sbvalue.setEnabled(true);
                            tipvalue = (sbvalue.getProgress()/100.0f) * Double.parseDouble(billvalue.getText().toString());
                            break;
                    }
                    tip.setText(String.format( "%.2f", tipvalue ));
                    Double totalvalue = tipvalue + Integer.parseInt(billvalue.getText().toString());
                    total.setText(String.format( "%.2f", totalvalue ));
                }
            }
        });

        sbvalue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                percent.setText(seekBar.getProgress()+"%");
                tipvalue = (sbvalue.getProgress()/100.0f) * Double.parseDouble(billvalue.getText().toString());
                tip.setText(String.format( "%.2f", tipvalue ));
                Double totalvalue = tipvalue + Integer.parseInt(billvalue.getText().toString());
                total.setText(String.format( "%.2f", totalvalue ));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                percent.setText(seekBar.getProgress()+"%");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                percent.setText(seekBar.getProgress()+"%");
            }
        });

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
                int pid = android.os.Process.myPid();
                android.os.Process.killProcess(pid);
            }
        });
    }
}
