package inclass05.com.group6_inclass05;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.LinkedList;

/**
 * Created by Durga Abayakumar on 2/12/2018.
 */

public class GetKeyWorkAsync extends AsyncTask<String,Void,LinkedList<String>> {

    LinkedList<String> keyWords = new LinkedList<>();

    IKeywords keys;
    public GetKeyWorkAsync(IKeywords newKeys){
        keys = newKeys;
    }

    @Override
    protected LinkedList<String> doInBackground(String... params) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        try {
            Log.d("demo", "doInBackground: ");
            URL url = new URL(params[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){//read result only if the response is ok.
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = "";
                while((line = reader.readLine()) != null){
                    Log.d("demo", "in line: " + line);
                    String[] list = line.split(";");
                    Log.d("demo", "doInBackground: " + list.length);
                    for(String str:list){
                        keyWords.add(str);
                    }

                }
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            if(connection!=null){
                connection.disconnect();
            }
            if(reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        for(String str:keyWords){
            Log.d("demo", "keywork size is: " +keyWords.size() + str);
        }

        return keyWords;

    }

    @Override
    protected void onPostExecute(LinkedList<String> strings) {
        keys.handleKeywords(keyWords);
    }

    public static interface IKeywords{
        public void handleKeywords(LinkedList<String> data);
    }
}
