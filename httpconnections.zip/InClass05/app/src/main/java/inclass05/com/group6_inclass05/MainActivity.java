package inclass05.com.group6_inclass05;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;

public class MainActivity extends AppCompatActivity implements GetKeyWorkAsync.IKeywords,GetURLWorkAsync.IURLs,GetBitMapAsync.IBitMap {

    TextView label;
    ImageView imgView;
    ProgressDialog progressDialog;
    ProgressDialog loadingDialog;
    LinkedList<String> finalKeys = new LinkedList<>();
    LinkedList<String> finalURLs = null;
    int increment = 0;
    boolean isLastElement = false;
    boolean isFirstElement = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        label = findViewById(R.id.txtActivity);
        imgView = findViewById(R.id.imageView);

        if(isConnected()){
            new GetKeyWorkAsync(MainActivity.this).execute("http://dev.theappsdr.com/apis/photos/keywords.php");
        }
        findViewById(R.id.btnGo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Choose a Keyword")
                        .setItems(finalKeys.toArray(new CharSequence[finalKeys.size()]), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int selected) {
                                label.setText(finalKeys.get(selected));
                                if(label.length()>0){
                                    String result = prepareURL(label.getText().toString());
                                    new GetURLWorkAsync(MainActivity.this).execute(result);
                                    progressDialog = new ProgressDialog(MainActivity.this);
                                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                                    progressDialog.setTitle("Loading Dictionary...");
                                    progressDialog.show();
                                }
                            }
                        });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

        findViewById(R.id.imgNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadingDialog = new ProgressDialog(MainActivity.this);
                loadingDialog.setTitle("Loading Photo....");
                loadingDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                Log.d("demo", "isLastElement: " + isLastElement);
                if(isLastElement){
                    new GetBitMapAsync(MainActivity.this).execute(finalURLs.get(0));
                    loadingDialog.show();
                }else{
                    increment++;
                    new GetBitMapAsync(MainActivity.this).execute(finalURLs.get(increment));
                    loadingDialog.show();
                    if(increment==finalURLs.size()-1){
                        isLastElement=true;
                        Log.d("demo", "Entering the loop: " + isLastElement);
                    }
                    Log.d("demo", "Incrementing : " + increment + finalURLs.size());
                }
            }
        });

        findViewById(R.id.imgPrev).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadingDialog = new ProgressDialog(MainActivity.this);
                loadingDialog.setTitle("Loading Photo....");
                loadingDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                if(isFirstElement){
                    int value = finalURLs.size()-1;
                    new GetBitMapAsync(MainActivity.this).execute(finalURLs.get(value));
                    loadingDialog.show();
                }else{
                    new GetBitMapAsync(MainActivity.this).execute(finalURLs.get(increment-1));
                    loadingDialog.show();
                    increment = increment-1;
                    if(increment==0){
                        isFirstElement = true;
                    }
                    Log.d("demo", "Decrementing : " + increment);
                }
            }
        });

    }

    private String prepareURL(String label) {
        StringBuilder URL = new StringBuilder();
        URL.append("http://dev.theappsdr.com/apis/photos/index.php");
        URL.append("?keyword=");
        URL.append(label);
        return URL.toString();
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if(networkInfo == null || !networkInfo.isConnected() &&
                networkInfo.getType()!= ConnectivityManager.TYPE_WIFI &&
                networkInfo.getType() != ConnectivityManager.TYPE_MOBILE){
            return false;
        }
        return true;
    }

    @Override
    public void handleKeywords(LinkedList<String> data) {
        finalKeys = data;

    }

    @Override
    public void handleURLs(LinkedList<String> data) {
        finalURLs = new LinkedList<>();
        finalURLs = data;
        increment=0;
        isLastElement=false;
        isFirstElement=false;
        if(finalURLs.size()==0){
            imgView.setImageBitmap(null);
            Toast.makeText(MainActivity.this,"No images found",Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();
        }else{
            new GetBitMapAsync(MainActivity.this).execute(finalURLs.get(increment));
        }

    }

    @Override
    public void handleImage(Bitmap bitmap) {
        if(progressDialog!=null){
            progressDialog.dismiss();
        }
        if(loadingDialog!=null){
            loadingDialog.dismiss();
        }
        imgView.setVisibility(View.VISIBLE);
        if(finalURLs.size()==1){
            findViewById(R.id.imgPrev).setEnabled(false);
            findViewById(R.id.imgNext).setEnabled(false);
            isFirstElement=false;
            isLastElement=false;
        }
        imgView.setImageBitmap(bitmap);
    }
}
