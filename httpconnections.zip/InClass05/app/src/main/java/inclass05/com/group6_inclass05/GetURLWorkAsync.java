package inclass05.com.group6_inclass05;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;

/**
 * Created by Durga Abayakumar on 2/12/2018.
 */

public class GetURLWorkAsync extends AsyncTask<String,Void,LinkedList<String>> {

    LinkedList<String> urls = new LinkedList<>();

   IURLs urlKeys;
    public GetURLWorkAsync(IURLs newKeys){
        urlKeys = newKeys;
    }

    @Override
    protected void onPostExecute(LinkedList<String> urlList) {
        urlKeys.handleURLs(urlList);
    }

    @Override
    protected LinkedList<String> doInBackground(String... params) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        try {
            URL url = new URL(params[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){//read result only if the response is ok.
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = "";
                while((line = reader.readLine()) != null){
                        urls.add(line);
                }
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            if(connection!=null){
                connection.disconnect();
            }
            if(reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return urls;

    }


    public static interface IURLs{
        public void handleURLs(LinkedList<String> data);
    }
}
