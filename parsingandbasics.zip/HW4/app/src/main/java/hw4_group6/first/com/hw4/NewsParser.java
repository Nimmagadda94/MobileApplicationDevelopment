package hw4_group6.first.com.hw4;

import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.util.Xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by Durga Abayakumar on 2/24/2018.
 */

public class NewsParser {

    public static class NewsSAXParsor extends DefaultHandler{
        ArrayList<News> newsList;
        News n;
        StringBuilder innerXML;

        static public ArrayList<News> parseNews(InputStream inputStream) throws IOException, SAXException {
            NewsSAXParsor parser = new NewsSAXParsor();
            Xml.parse(inputStream,Xml.Encoding.UTF_8,parser);
            return parser.newsList;
        }

        @Override
        public void startDocument() throws SAXException {
            super.startDocument();
            this.newsList = new ArrayList<>();
            this.innerXML = new StringBuilder();
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            if(localName.equals("item"))    {
                n = new News();
            }else if(qName.equals("media:content")){
                n.setUrlToImage(attributes.getValue("url"));
                innerXML.setLength(0);
            }else if(qName.equals("media:thumbnail")){
                n.setUrlToImage(attributes.getValue("url"));
                innerXML.setLength(0);
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            String text = "";
            if(innerXML.toString()!=null){
                text = innerXML.toString().trim();//removes leading spaces

            }else{
                text = " ";
            }
            if(newsList.size() < 21){
                if(n instanceof News && n!=null){
                    if(localName.equals("title")){
                        n.setTitle(text);
                    }
                    else if(localName.equals("link")){
                        n.setNewsLink(text);
                    }
                    else if(localName.equals("description")){
                        Spanned result = stripHtml(text);
                        String[] str = text.toString().split(".");
                        n.setDescription(result.toString());
                    }
                    else  if(localName.equals("pubDate")){
                        n.setPublishedAt(text);
                    }
                    else if(localName.equals("item")){
                        newsList.add(n);
                    }

                    Log.d("demo", "arraylist size :  " + newsList.size());
                    innerXML.setLength(0);
                }
            }
        }

        public Spanned stripHtml(String html) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                Spanned text =  Html.fromHtml(html, Html.FROM_HTML_SEPARATOR_LINE_BREAK_DIV);
                return text;
            }
            return null;
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            super.characters(ch, start, length);
            innerXML.append(ch,start,length);
        }

    }
}
