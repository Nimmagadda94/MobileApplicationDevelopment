package hw4_group6.first.com.hw4;

import android.os.AsyncTask;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Durga Abayakumar on 2/24/2018.
 */

class GetNewsAsync extends AsyncTask<String,Void,ArrayList<News>> {

    ArrayList<News> keyNews = new ArrayList<>();

    IKeywords keys;
    public GetNewsAsync(IKeywords newKeys){
        keys = newKeys;
    }

    @Override
    protected ArrayList<News> doInBackground(String... strings) {

        StringBuilder sb = new StringBuilder();

        HttpURLConnection connection = null;
        BufferedReader reader = null;
        try{
            URL url = new URL(strings[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {//read result only if the response is ok.
                try {
                    keyNews = NewsParser.NewsSAXParsor.parseNews(connection.getInputStream());
                }catch (SAXException e) {
                    e.printStackTrace();
                }
            }

        }catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return keyNews;

    }

    @Override
    protected void onPostExecute(ArrayList<News> strings) {
        keys.handleKeywords(strings);
    }

    public static interface IKeywords{
        public void handleKeywords(ArrayList<News> data);
    }


}
