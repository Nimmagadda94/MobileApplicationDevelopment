package hw4_group6.first.com.hw4;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements GetNewsAsync.IKeywords{

    ArrayList<String> finalKeys = new ArrayList<>();

    ArrayList<News> newsInfo = new ArrayList<News>();

    ProgressDialog progressDialog;
    TextView txtView;
    TextView newsTitle;
    TextView publishAt;
    TextView newsDes;
    ImageView imageUrl;
    TextView txtPageInfo;
    static int count = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtView = findViewById(R.id.txtCategory);

        finalKeys.add("Top Stories");
        finalKeys.add("World");
        finalKeys.add("U.S.");
        finalKeys.add("Business");
        finalKeys.add("Politics");
        finalKeys.add("Technology");
        finalKeys.add("Health");
        finalKeys.add("Entertainment");
        finalKeys.add("Travel");
        finalKeys.add("Living");
        finalKeys.add("Most Recent");

        newsTitle = findViewById(R.id.txtTitle);
        publishAt = findViewById(R.id.txtPublishAt);
        newsDes = findViewById(R.id.txtDesc);
        imageUrl = findViewById(R.id.imgPic);
        txtPageInfo = findViewById(R.id.txtPageInfo);

        findViewById(R.id.imgPrev).setEnabled(false);
        findViewById(R.id.imgNext).setEnabled(false);

        findViewById(R.id.btnGo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Choose Category")
                        .setItems(finalKeys.toArray(new CharSequence[finalKeys.size()]), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int selected) {
                                txtView.setText(finalKeys.get(selected));
                                if(txtView.length()>0){
                                    findViewById(R.id.imgPrev).setEnabled(false);
                                    findViewById(R.id.imgNext).setEnabled(false);
                                    count=1;
                                    progressDialog = new ProgressDialog(MainActivity.this);
                                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                                    progressDialog.setTitle("Loading News...");
                                    progressDialog.show();
                                    if(isConnected()){
                                        String category = txtView.getText().toString();
                                        switch (category){
                                            case "Top Stories":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_topstories.rss");
                                                break;
                                            case "World":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_world.rss");
                                                break;
                                            case "U.S.":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_us.rss");
                                                break;
                                            case "Business":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/money_latest.rss");
                                                break;
                                            case "Politics":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_allpolitics.rss");
                                                break;
                                            case "Technology":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_tech.rss");
                                                break;
                                            case "Health":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_health.rss");
                                                break;
                                            case "Entertainment":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_showbiz.rss");
                                                break;
                                            case "Travel":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_travel.rss");
                                                break;
                                            case "Living":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_living.rss");
                                                break;
                                            case "Most Recent":
                                                new GetNewsAsync(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_latest.rss");
                                                break;
                                        }
                                    }
                                }
                            }
                        });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

        findViewById(R.id.imgNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count++;
                if(count==21){
                    count = 1;
                }
                displayNews();
            }
        });

        findViewById(R.id.imgPrev).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count--;
                if(count==0){
                    count=20;
                }
                displayNews();
            }
        });

        findViewById(R.id.txtTitle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(newsInfo.get(count).getNewsLink()));
                startActivity(browserIntent);
            }
        });

        findViewById(R.id.imgPic).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(newsInfo.get(count).getNewsLink()));
                startActivity(browserIntent);
            }
        });

    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if(networkInfo == null || !networkInfo.isConnected() &&
                networkInfo.getType()!= ConnectivityManager.TYPE_WIFI &&
                networkInfo.getType() != ConnectivityManager.TYPE_MOBILE){
            return false;
        }
        return true;
    }

    @Override
    public void handleKeywords(ArrayList<News> data) {
        progressDialog.dismiss();
        newsInfo = data;
        if(newsInfo.size()==0){
            newsTitle.setText("");
            publishAt.setText("");
            imageUrl.setImageBitmap(null);
            newsDes.setText("");
            txtPageInfo.setText(" ");
            Toast.makeText(getApplicationContext(),"No news found",Toast.LENGTH_SHORT).show();
        }
        if(newsInfo.size()>1){
            findViewById(R.id.imgPrev).setEnabled(true);
            findViewById(R.id.imgNext).setEnabled(true);
            displayNews();
        }
    }

    private void displayNews() {
        News n = new News();
        n = newsInfo.get(count);
        if(n.getTitle()!=null){
            newsTitle.setText(n.getTitle());
        }
        if(n.getPublishedAt()!=null){
            publishAt.setText(n.getPublishedAt());
        }
        if(n.getUrlToImage()!=null){
            if(isConnected()){
                imageUrl.setVisibility(View.VISIBLE);
                Picasso.with(getApplicationContext())
                        .load(n.getUrlToImage())
                        .resize(800, 500)
                        .centerCrop()
                        .into(imageUrl);
            }else{
                Toast.makeText(getApplicationContext(),"No internet connection and do not attempt to send the HTTP request",Toast.LENGTH_LONG).show();
            }
        }
        if(n.getDescription()!=null){
            newsDes.setText(n.getDescription());
        }else{
            newsDes.setText("");
        }
        txtPageInfo.setText(count + " of " + (newsInfo.size()-1));
    }
}
