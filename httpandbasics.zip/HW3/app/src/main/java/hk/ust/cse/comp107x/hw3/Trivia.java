package hk.ust.cse.comp107x.hw3;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

import hk.ust.cse.comp107x.hw3.Question;

public class Trivia extends AppCompatActivity implements LoadingImageAsync.IBitMap{

    TextView questionNo;
    ImageView image;
    TextView timer;
    TextView question;
    RadioGroup rg;
    RadioButton rb;
    HashMap<Integer,Question> triviaQues = new HashMap<Integer,Question>();
    ProgressDialog loadingDialog;

    static int questionCount = 0;

    CountDownTimer waitTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia);

        questionNo = findViewById(R.id.txtQuesNo);
        question = findViewById(R.id.txtQuestion);
        timer = findViewById(R.id.txtTimer);



        waitTimer = new CountDownTimer(120000, 1000) {

            public void onTick(long millisUntilFinished) {
                timer.setText("Time Left: " + millisUntilFinished / 1000 + "seconds");
            }

            public void onFinish() {
                Intent statsIntent = new Intent(Trivia.this,Stats.class);
                statsIntent.putExtra("result",triviaQues);
                startActivity(statsIntent);
            }
        }.start();

        image = findViewById(R.id.imageView2);
        rg = (RadioGroup)findViewById(R.id.rg);

        loadProgressbar();

        findViewById(R.id.btnQuit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                questionCount = 0;
                Intent goToMain = new Intent(Trivia.this,MainActivity.class);
                goToMain.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(goToMain);
            }
        });

        if(getIntent()!=null && getIntent().getExtras()!=null){
            triviaQues = (HashMap<Integer, Question>) getIntent().getExtras().getSerializable("TRIVIA_QUES");
            displayTriviaQuiz(triviaQues);
        }


        findViewById(R.id.btnNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    int id= rg.getCheckedRadioButtonId();
                    Log.d("demo", "selected option: " + id);
                    triviaQues.get(questionCount).setUserEnteredAnswer(String.valueOf(id));
                    if(String.valueOf(id).equals(triviaQues.get(questionCount).getCorrectAnswer()))
                    {
                        Log.d("demo", "Answers match for question : "+ questionCount + " " + id + " "+triviaQues.get(questionCount).getCorrectAnswer());
                        triviaQues.get(questionCount).setAnswerCount(1);
                    }else{
                        Log.d("demo", "Answers dont match : " + id + " "+triviaQues.get(questionCount).getCorrectAnswer());
                        triviaQues.get(questionCount).setAnswerCount(0);
                    }
                    questionCount++;
                    clearAllFields();
                displayTriviaQuiz(triviaQues);
            }
        });

    }

    private void clearAllFields() {
        rg.removeAllViews();
        questionNo.setText("");
        image.setImageBitmap(null);
        question.setText("");
    }

    private void displayTriviaQuiz(HashMap<Integer, Question> triviaQues) {
        if(questionCount==16){
            if(waitTimer != null) {
                waitTimer.cancel();
                waitTimer = null;
            }
            Intent statsIntent = new Intent(Trivia.this,Stats.class);
            statsIntent.putExtra("result",triviaQues);
            startActivity(statsIntent);

        }else{
            int questionnumber = triviaQues.get(questionCount).getQuestionNo()+1;
            questionNo.setText("Q" + String.valueOf(questionnumber));
            question.setText(triviaQues.get(questionCount).getQuestion());
            if(triviaQues.get(questionCount).getImage()!=null){
                loadingDialog.show();
                new LoadingImageAsync(Trivia.this).execute(triviaQues.get(questionCount).getImage());
            }else{
                image.setImageBitmap(null);
            }
            displayAnswerChoice(triviaQues.get(questionCount).getAnswerChoices());

        }
    }

    private void loadProgressbar() {
        loadingDialog = new ProgressDialog(this);
        loadingDialog.setTitle("Loading photo");
        loadingDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
    }

    private void displayAnswerChoice(ArrayList<String> triviaAnswers) {

        for(int i=0;i<triviaAnswers.size();i++){
            rb = new RadioButton(this);
            rb.setVisibility(View.VISIBLE);
            rb.setId(i);
            rb.setText(triviaAnswers.get(i));
            Log.d("demo", "Answer Choices are:: " + triviaAnswers.get(i));
            rg.addView(rb);
        }
    }

    @Override
    public void handleImage(Bitmap bitmap) {
        loadingDialog.dismiss();
        image.setVisibility(View.VISIBLE);
        image.setImageBitmap(bitmap);
    }
}
