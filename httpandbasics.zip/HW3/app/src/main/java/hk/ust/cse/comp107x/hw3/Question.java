package hk.ust.cse.comp107x.hw3;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Vasanthi Nimmagadda on 2/14/2018.
 */

public class Question implements Serializable{

    private int questionNo;
    private String question;
    private String image;
    private ArrayList<String> answerChoices;
    private String correctAnswer;
    private String userEnteredAnswer;
    private int answerCount;

    public int getQuestionNo() {
        return questionNo;
    }

    public void setQuestionNo(int questionNo) {
        this.questionNo = questionNo;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public ArrayList<String> getAnswerChoices() {
        return answerChoices;
    }

    public void setAnswerChoices(ArrayList<String> answerChoices) {
        this.answerChoices = answerChoices;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public String getUserEnteredAnswer() {
        return userEnteredAnswer;
    }

    public void setUserEnteredAnswer(String userEnteredAnswer) {
        this.userEnteredAnswer = userEnteredAnswer;
    }

    public int getAnswerCount() {
        return answerCount;
    }

    public void setAnswerCount(int answerCount) {
        this.answerCount = answerCount;
    }


}
