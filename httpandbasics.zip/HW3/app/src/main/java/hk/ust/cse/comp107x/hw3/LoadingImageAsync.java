package hk.ust.cse.comp107x.hw3;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Vasanthi Nimmagadda on 2/15/2018.
 */

public class LoadingImageAsync extends AsyncTask<String,Void,Bitmap> {

    Bitmap imgResult = null;
    IBitMap bitMap;

    public LoadingImageAsync(IBitMap btMap) {
        bitMap = btMap;
    }

    @Override
    protected Bitmap doInBackground(String... params) {
        StringBuilder stringBuilder = new StringBuilder();
        HttpURLConnection connection = null;

        try {
            URL url = new URL(params[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){//read result only if the response is ok.
                imgResult = BitmapFactory.decodeStream(connection.getInputStream());
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            if(connection!=null){
                connection.disconnect();
            }

        }
        return imgResult;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        bitMap.handleImage(bitmap);
    }

    public static interface IBitMap{
        public void handleImage(Bitmap bitmap);
    }
}
