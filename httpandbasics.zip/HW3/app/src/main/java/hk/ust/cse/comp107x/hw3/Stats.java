package hk.ust.cse.comp107x.hw3;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import hk.ust.cse.comp107x.hw3.Question;

public class Stats extends AppCompatActivity {

    HashMap<Integer,Question> triviaResult = new HashMap<Integer,Question>();
    static int totalQues = 16;
    static int correctAnswers = 0;
    int result=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        ProgressBar pb = findViewById(R.id.progressBar);
        TextView txtResult = findViewById(R.id.txtProgress);

        findViewById(R.id.btnQuit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToMain = new Intent(Stats.this,MainActivity.class);
                startActivity(goToMain);
            }
        });

        findViewById(R.id.btnTryAgain).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToTriviaQues = new Intent(Stats.this,Trivia.class);
                goToTriviaQues.putExtra("TRIVIA_QUES",triviaResult);
                Trivia.questionCount=0;
                correctAnswers = 0;
                startActivity(goToTriviaQues);
            }
        });

        if(getIntent()!=null && getIntent().getExtras()!=null){
            triviaResult = (HashMap<Integer, Question>) getIntent().getExtras().getSerializable("result");
            Iterator it = triviaResult.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry)it.next();
                Question t = (Question)pair.getValue();
                if(t.getAnswerCount()==1){
                    correctAnswers++;
                }
            }
            Log.d("demo", "total correct answers are : " + correctAnswers);
            float value = correctAnswers * 100 / 16;
            Log.d("demo", "result is: " + value);
            result = Math.round(value);
            Log.d("demo", "percentage correction : " + result);
            pb.setProgress(result);
            txtResult.setText(result +"%");
        }
    }
}
