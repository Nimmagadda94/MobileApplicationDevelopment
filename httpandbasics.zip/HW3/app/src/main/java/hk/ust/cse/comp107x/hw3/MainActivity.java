package hk.ust.cse.comp107x.hw3;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements GetTriviaAsync.IQuestions{

    ProgressDialog progressDialog;
    HashMap<Integer,Question> triviaQues = new HashMap<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(isConnected()){
            new GetTriviaAsync(MainActivity.this).execute("http://dev.theappsdr.com/apis/trivia_json/trivia_text.php");
            displayProgress();
        }

        findViewById(R.id.btnStart).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Trivia.class);
                intent.putExtra("TRIVIA_QUES",triviaQues);
                startActivity(intent);
            }
        });

        findViewById(R.id.btnExit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                int pid = android.os.Process.myPid();
                android.os.Process.killProcess(pid);
                System.exit(0);
            }
        });

    }

    private void displayProgress() {
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setTitle("Loading Trivia");
        progressDialog.show();
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if(networkInfo == null || !networkInfo.isConnected() &&
                networkInfo.getType()!= ConnectivityManager.TYPE_WIFI &&
                networkInfo.getType() != ConnectivityManager.TYPE_MOBILE){
            return false;
        }
        return true;
    }

    @Override
    public void handleKeywords(HashMap<Integer, Question> map) {
        triviaQues = map;
        progressDialog.dismiss();
        findViewById(R.id.imageView).setVisibility(View.VISIBLE);
        findViewById(R.id.textView2).setVisibility(View.VISIBLE);
        findViewById(R.id.btnStart).setEnabled(true);
    }
}
