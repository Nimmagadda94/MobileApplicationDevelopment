package hk.ust.cse.comp107x.hw3;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReferenceArray;

import hk.ust.cse.comp107x.hw3.Question;

/**
 * Created by Durga Abayakumar on 2/14/2018.
 */

public class GetTriviaAsync extends AsyncTask<String,Void,HashMap<Integer,Question>> {

    HashMap<Integer,Question> map = new HashMap<>();

    IQuestions questions;
    public GetTriviaAsync(IQuestions questions1){
        questions = questions1;
    }

    @Override
    protected HashMap<Integer, Question> doInBackground(String... params) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        try {
            URL url = new URL(params[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){//read result only if the response is ok.
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = "";
                while((line = reader.readLine()) != null){
                    String[] list = line.split(";");
                    Question trivia = new Question();
                    ArrayList<String> answers = new ArrayList<>();
                    for(int i=0;i<list.length;i++){
                        int totalSize = list.length;
                        if(i==0){
                            String key = list[0];
                            trivia.setQuestionNo(Integer.parseInt(key));
                        }
                        if(i==1){
                            trivia.setQuestion(list[i]);
                        }
                        if(i==2){
                            if(list[i].length()!=0) {
                                trivia.setImage(list[i]);
                            }
                        }
                        if(i==totalSize-1){
                            trivia.setCorrectAnswer(list[totalSize-1]);
                        }
                        if(i==3){
                            for(int j=i;j<=totalSize-2;j++){
                                answers.add(list[j]);
                            }
                            trivia.setAnswerChoices(answers);
                        }
                        trivia.setAnswerCount(0);//setting the answer count to 0
                        map.put(trivia.getQuestionNo(),trivia);
                    }

                }
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            if(connection!=null){
                connection.disconnect();
            }
            if(reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        sortedMap(map);
        Iterator<Map.Entry<Integer, Question>> it = map.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry pair = (Map.Entry)it.next();
            Question t = (Question) pair.getValue();
            Log.d("demo", "iterating the values: " + pair.getKey() + t.getQuestion() + t.getAnswerChoices().size());
        }

        return map;

    }

    private void sortedMap(HashMap<Integer, Question> map) {
        List<Integer> mapKeys = new ArrayList<>(map.keySet());
        Collections.sort(mapKeys);
    }



    @Override
    protected void onPostExecute(HashMap<Integer, Question> stringTriviaHashMap) {
        questions.handleKeywords(map);
    }

    public static interface IQuestions{
        public void handleKeywords(HashMap<Integer, Question> quesMap);
    }
}
