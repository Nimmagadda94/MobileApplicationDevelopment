package hk.ust.cse.comp107x.inclass03;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Toast;

public class EditActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        if(getIntent()!= null && getIntent().getExtras()!=null){
            if(getIntent().getExtras().getString(DisplayActivity.NAME_KEY)!=null){
                //Log.d("demo", getIntent().getExtras().getString(DisplayActivity.NAME_KEY));
                findViewById(R.id.editText).setVisibility(View.VISIBLE);
                findViewById(R.id.button).setVisibility(View.VISIBLE);
                final EditText name = (EditText) findViewById(R.id.editText);
                name.setText(getIntent().getExtras().getString(DisplayActivity.NAME_KEY));
                findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(name.getText().toString()==null || name.getText().toString().length()==0){
                            Toast.makeText(getApplicationContext(), "Enter Your text", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Intent intent = new Intent();
                            intent.putExtra(DisplayActivity.NAME_KEY, name.getText().toString());
                            setResult(RESULT_OK,intent);
                        }
                        finish();
                    }
                });
            }

            else if(getIntent().getExtras().getString(DisplayActivity.EMAIL_KEY)!=null){
                //Log.d("demo", getIntent().getExtras().getString(DisplayActivity.EMAIL_KEY));
                findViewById(R.id.editText2).setVisibility(View.VISIBLE);
                findViewById(R.id.button).setVisibility(View.VISIBLE);
                final EditText email = (EditText) findViewById(R.id.editText2);
                email.setText(getIntent().getExtras().getString(DisplayActivity.EMAIL_KEY));
                findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(email.getText().toString()==null || email.getText().toString().length()==0){
                            Toast.makeText(getApplicationContext(), "Enter Your email", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Intent intent = new Intent();
                            intent.putExtra(DisplayActivity.EMAIL_KEY, email.getText().toString());
                            setResult(RESULT_OK,intent);
                        }
                        finish();
                    }
                });
            }

           else if(getIntent().getExtras().getString(DisplayActivity.DEP_KEY)!=null){
                //Log.d("demo", getIntent().getExtras().getString(DisplayActivity.DEP_KEY));
                findViewById(R.id.textView).setVisibility(View.VISIBLE);
                findViewById(R.id.radioGroup).setVisibility(View.VISIBLE);
                findViewById(R.id.button).setVisibility(View.VISIBLE);
                switch(getIntent().getExtras().getString(DisplayActivity.DEP_KEY)) {
                    case "SIS":
                        ((RadioButton) findViewById(R.id.radioButton)).setChecked(true);
                        break;
                    case "CS":
                        ((RadioButton) findViewById(R.id.radioButton2)).setChecked(true);
                        break;
                        case "BIC":
                        ((RadioButton) findViewById(R.id.radioButton3)).setChecked(true);
                        break;
                    case "Others":
                        ((RadioButton) findViewById(R.id.radioButton3)).setChecked(true);
                        break;


                }
                /*RadioGroup btn = (RadioGroup) findViewById(R.id.radioGroup);
                final RadioButton dep = (RadioButton) findViewById(btn.getCheckedRadioButtonId());*/
                findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        RadioGroup btn = (RadioGroup) findViewById(R.id.radioGroup);
                        RadioButton dep = (RadioButton) findViewById(btn.getCheckedRadioButtonId());
                        if(dep.getText().toString()==null){
                            Toast.makeText(getApplicationContext(), "Select Your department", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Intent intent = new Intent();
                            intent.putExtra(DisplayActivity.DEP_KEY, dep.getText().toString());
                            setResult(RESULT_OK,intent);
                        }
                        finish();
                    }
                });

            }

            else if(getIntent().getExtras().getInt(DisplayActivity.MOOD_KEY)!=0){
                //Log.d("demo", getIntent().getExtras().getString(DisplayActivity.MOOD_KEY));
                findViewById(R.id.textView2).setVisibility(View.VISIBLE);
                findViewById(R.id.seekBar).setVisibility(View.VISIBLE);
                findViewById(R.id.button).setVisibility(View.VISIBLE);
                final SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar);
                seekBar.setProgress(getIntent().getExtras().getInt(DisplayActivity.MOOD_KEY));
                findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(seekBar.getProgress()==0){
                            Toast.makeText(getApplicationContext(), "Specify the Mood", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Intent intent = new Intent();
                            intent.putExtra(DisplayActivity.MOOD_KEY, seekBar.getProgress());
                            setResult(RESULT_OK,intent);
                        }
                        finish();
                    }
                });
            }
        }


    }
}
