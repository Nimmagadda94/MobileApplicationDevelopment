package hk.ust.cse.comp107x.inclass03;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    final Student student = new Student();

    static String NAME_KEY = "studentinfo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText name = (EditText) findViewById(R.id.editText);
                student.setName(name.getText().toString());
                //Log.d("demo", student.getName());
                EditText email = (EditText) findViewById(R.id.editText2);
                student.setEmail(email.getText().toString());
                boolean depSelected = true;
                try {
                    RadioGroup btn = (RadioGroup) findViewById(R.id.radioGroup);
                    RadioButton dep = (RadioButton) findViewById(btn.getCheckedRadioButtonId());
                    student.setDepartment(dep.getText().toString());
                }
                catch (Exception e)
                {
                   depSelected = false;
                }
                SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar);
                student.setMood(seekBar.getProgress());

                if(name.getText().toString()==null || name.getText().toString().length()==0){
                    Toast.makeText(getApplicationContext(), "Enter your name", Toast.LENGTH_SHORT).show();
                }
                else if(email.getText().toString()==null || email.getText().toString().length()==0){
                    Toast.makeText(getApplicationContext(), "Enter your Email", Toast.LENGTH_SHORT).show();
                }
                else if(seekBar.getProgress()==0){
                    Toast.makeText(getApplicationContext(), "Select your Mood", Toast.LENGTH_SHORT).show();
                }
                else if(!depSelected) {
                    Toast.makeText(getApplicationContext(), "Select your department", Toast.LENGTH_SHORT).show();
                }

                else{
                    Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
                    intent.putExtra(NAME_KEY, student);
                    startActivity(intent);
                }

            }


        });


    }
}
