package hk.ust.cse.comp107x.inclass03;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class DisplayActivity extends AppCompatActivity {

    public static final int CODE_NAME = 100;
    public static final int CODE_EMAIL = 200;
    public static final int CODE_DEP = 300;
    public static final int CODE_MOOD = 400;
    static String NAME_KEY = "name";
    static String EMAIL_KEY = "email";
    static String DEP_KEY = "dep";
    static String MOOD_KEY = "mood";
    //final Student student = (Student) getIntent().getExtras().getSerializable(MainActivity.NAME_KEY);

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == CODE_NAME){
            if(resultCode == RESULT_OK){
                TextView name = (TextView) findViewById(R.id.textView8);
                name.setText(data.getExtras().getString(NAME_KEY));
            }
        }
        else if(requestCode == CODE_EMAIL){
            if(resultCode == RESULT_OK){
                TextView email = (TextView) findViewById(R.id.textView9);
                email.setText(data.getExtras().getString(EMAIL_KEY));
            }
        }
        else if(requestCode == CODE_DEP){
            if(resultCode == RESULT_OK){
                TextView dep = (TextView) findViewById(R.id.textView10);
                dep.setText(data.getExtras().getString(DEP_KEY));
            }
        }
        else if(requestCode == CODE_MOOD){
            if(resultCode == RESULT_OK){
                TextView mood = (TextView) findViewById(R.id.textView11);
                mood.setText(data.getExtras().getInt(MOOD_KEY)+"% Positive");
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        /*if(getIntent()!= null && getIntent().getExtras()!=null){
            Student student = (Student) getIntent().getExtras().getSerializable(MainActivity.NAME_KEY);
            Toast.makeText(this, student.getName().toString(), Toast.LENGTH_SHORT).show();
        }*/

        final Student student = (Student) getIntent().getExtras().getSerializable(MainActivity.NAME_KEY);

        TextView name = (TextView) findViewById(R.id.textView8);
        name.setText(student.getName());
        TextView email = (TextView) findViewById(R.id.textView9);
        email.setText(student.getEmail());
        TextView dep = (TextView) findViewById(R.id.textView10);
        dep.setText(student.getDepartment());
        TextView mood = (TextView) findViewById(R.id.textView11);
        mood.setText(student.getMood()+"% Positive");

        findViewById(R.id.editname).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentname = new Intent("hk.ust.cse.comp107x.inclass03.intent.action.VIEW");
                intentname.putExtra(NAME_KEY, student.getName());
                startActivityForResult(intentname, 100);
            }
        });

        findViewById(R.id.editemail).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentname = new Intent("hk.ust.cse.comp107x.inclass03.intent.action.VIEW");
                intentname.putExtra(EMAIL_KEY, student.getEmail());
                startActivityForResult(intentname, 200);
            }
        });

        findViewById(R.id.editdep).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentname = new Intent("hk.ust.cse.comp107x.inclass03.intent.action.VIEW");
                intentname.putExtra(DEP_KEY, student.getDepartment());
                startActivityForResult(intentname, 300);
            }
        });

        findViewById(R.id.editmood).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentname = new Intent("hk.ust.cse.comp107x.inclass03.intent.action.VIEW");
                intentname.putExtra(MOOD_KEY, student.getMood());
                startActivityForResult(intentname, 400);
            }
        });



    }
}
