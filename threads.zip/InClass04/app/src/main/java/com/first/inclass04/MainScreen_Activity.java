package com.first.inclass04;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainScreen_Activity extends AppCompatActivity {

    TextView txtCount, txtLength, txtPassword;
    SeekBar seekBarCount, seekBarLength;

    ExecutorService myThreadPool;
    ProgressDialog progressDialogForThread;
    ProgressDialog progressDialogForAsync;
    AlertDialog alertDialog;
    Handler handler;
    List<String> pwdListForThread = new ArrayList<String>();
    List<String> pwdListForAsync = new ArrayList<String>();
    CharSequence[] charSequenceItemsForThread;
    CharSequence[] charSequenceItemsForAsync;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
        setTitle("InClass04");

        seekBarCount = findViewById(R.id.seekBarCount);
        seekBarLength = findViewById(R.id.seekBarLength);
        txtCount = findViewById(R.id.txtCount);
        txtLength = findViewById(R.id.txtLength);
        txtPassword = findViewById(R.id.txtPassword);

        seekBarCount.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                txtCount.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
//                txtCount.setText(String.valueOf(progress));
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
//                txtCount.setText(String.valueOf(progress));
            }
        });

        seekBarLength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                txtLength.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        progressDialogForThread = new ProgressDialog(MainScreen_Activity.this);
        progressDialogForThread.setTitle("Generating Passwords....");
        progressDialogForThread.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialogForThread.setCancelable(false);
        myThreadPool = Executors.newFixedThreadPool(2);

        findViewById(R.id.btnThread).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialogForThread.setMax(Integer.parseInt(txtCount.getText().toString()));
                progressDialogForThread.show();
                for (int i = 0; i < Integer.parseInt(txtCount.getText().toString()); i++) {
                    myThreadPool.execute(new GeneratePassword());
                }
            }
        });

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message message) {
                pwdListForThread.add((String) message.obj);
                Log.d("demo", "arraylist size: " + pwdListForThread.size());
                progressDialogForThread.incrementProgressBy(1);
                if(pwdListForThread.size()==Integer.parseInt(txtCount.getText().toString())){
                    progressDialogForThread.dismiss();
                    charSequenceItemsForThread = pwdListForThread.toArray(new CharSequence[pwdListForThread.size()]);
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainScreen_Activity.this);
                    builder.setTitle("Passwords:")
                            .setItems(charSequenceItemsForThread, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    txtPassword.setText(charSequenceItemsForThread[i]);
                                }
                            });
                    alertDialog = builder.create();
                    alertDialog.show();
                }

                return false;
            }
        });

        findViewById(R.id.btnAsync).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AsyncGeneration().execute(Integer.parseInt(txtCount.getText().toString()),Integer.parseInt(txtLength.getText().toString()));
            }
        });
    }

    class GeneratePassword implements Runnable {
        @Override
        public void run() {
            Log.d("demo", "ENtering run()");
            String pwd = Util.getPassword(Integer.parseInt(txtLength.getText().toString()));
            Message msg = new Message();
            msg.obj = pwd;
            handler.sendMessage(msg);
        }

    }

    class AsyncGeneration extends AsyncTask<Integer, Integer, List<String>> {

        @Override
        protected void onPreExecute() {//performed by main thread
            progressDialogForAsync = new ProgressDialog(MainScreen_Activity.this);
            progressDialogForAsync.setTitle("Generating Passwords....");
            progressDialogForAsync.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialogForAsync.setCancelable(false);
            progressDialogForAsync.setMax(Integer.parseInt(txtCount.getText().toString()));
            progressDialogForAsync.show();
            Log.d("tag", "onPreExecute: ");
        }

        @Override
        protected void onPostExecute(List<String> s) {//performed by main thread
            Log.d("tag", "onPostExecute: ");
            progressDialogForAsync.dismiss();
            if(pwdListForAsync.size()==Integer.parseInt(txtCount.getText().toString())){
                progressDialogForAsync.dismiss();
                charSequenceItemsForAsync = pwdListForAsync.toArray(new CharSequence[pwdListForAsync.size()]);
                AlertDialog.Builder builder = new AlertDialog.Builder(MainScreen_Activity.this);
                builder.setTitle("Passwords:")
                        .setItems(charSequenceItemsForAsync, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                txtPassword.setText(charSequenceItemsForAsync[i]);
                            }
                        });
                alertDialog = builder.create();
                alertDialog.show();
            }
        }

        @Override
        protected void onProgressUpdate(Integer... values) {//performed by main thread
            Log.d("tag", "onProgressUpdate: " + values[0]);
            progressDialogForAsync.incrementProgressBy(values[0]+1);
        }

        @Override
        protected List<String> doInBackground(Integer... integers) {//performed by the runnable child thread
            Log.d("tag", "doInBackground: " +integers[0] + integers[1]);
            for(int i=0;i<integers[0];i++){
                String pwd = Util.getPassword(integers[1]);
                Log.d("tag", "doInBackground: " + pwd);
                publishProgress(i);
                pwdListForAsync.add(pwd);
                Log.d("tag", "doInBackground: final list size is :" + pwdListForAsync.size());
            }
            return pwdListForAsync;
        }
    }

}
