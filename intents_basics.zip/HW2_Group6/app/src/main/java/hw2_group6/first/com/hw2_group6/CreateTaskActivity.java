package hw2_group6.first.com.hw2_group6;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedList;
import java.util.Locale;

public class CreateTaskActivity extends AppCompatActivity {

    private Calendar newCalendar = Calendar.getInstance();
    private Calendar timeCalendar = Calendar.getInstance();

    private DatePickerDialog datePickerDialog;
    private TimePickerDialog timePickerDialog;

    private EditText title;
    private EditText dateText;
    private EditText timeText;
    RadioGroup rg;
    RadioButton rd;

    private SimpleDateFormat dateFormatter = new SimpleDateFormat("MM-dd-yyyy", Locale.US);

    private SimpleDateFormat timeFormatter = new SimpleDateFormat("hh:mm a", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.to_do_img);
        setTitle(R.string.create_task_name);

        title = findViewById(R.id.txtTitle);

//        dateFormatter = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
        dateText = findViewById(R.id.txtDate);
        dateText.setOnKeyListener(null);
        dateText.setKeyListener(null);
        dateText.requestFocus();
        final DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                newCalendar.set(Calendar.YEAR, year);
                newCalendar.set(Calendar.MONTH, monthOfYear);
                newCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                dateText.setText(dateFormatter.format(newCalendar.getTime()));
            }
        };
        dateText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(CreateTaskActivity.this, dateSetListener, newCalendar.get(Calendar.YEAR),
                        newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        timeText = findViewById(R.id.txtTime);
        timeText.setOnKeyListener(null);
        timeText.setKeyListener(null);
        timeText.requestFocus();
        timeText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo", "Time dialog to show up");
                createTimeDialog();
                timePickerDialog.setTitle(R.string.time_dialog_title);
                timePickerDialog.show();
            }
        });

        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo", "Saving the data...!");
                boolean isValid = validateFields();
                if (isValid) {
                    Task newTask = new Task();
                    newTask.setTaskTitle(title.getText().toString());
                    newTask.setTaskDate(dateText.getText().toString());
                    newTask.setTaskTime(timeText.getText().toString());
                    rg = findViewById(R.id.radioGroup);
                    rd = (RadioButton) findViewById(rg.getCheckedRadioButtonId());
                    newTask.setTaskPriority(rd.getText().toString());
                    sortTaskList(newTask);
                    updateTaskNumbers(MainActivity.taskList);
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra(MainActivity.CREATE_TASK, newTask);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                }
            }
        });
    }

    private void sortTaskList(Task newTask) {

        if (MainActivity.taskList.size() == 0) {
            MainActivity.taskList.add(newTask);
        } else {
            LinkedList<Task> sortingList = new LinkedList<>(MainActivity.taskList);
            sortingList.add(newTask);
            Log.d("demo", "Sorting list is : " + sortingList.size());
            Collections.sort(sortingList, new Comparator<Task>() {
                @Override
                public int compare(Task task1, Task task2) {
                    int result = 0;
                    SimpleDateFormat sdf = new SimpleDateFormat("mm-dd-yyyy");
                    SimpleDateFormat format = new SimpleDateFormat("HH:mm");
                    try {
                        Date date1 = sdf.parse(task1.getTaskDate());
                        Date date2 = sdf.parse(task2.getTaskDate());
                        Date time1 = format.parse(task1.getTaskTime());
                        Date time2 = format.parse(task2.getTaskTime());
                        Log.d("demo", "both the date values : " + date1 + " " + date2);
                        result = date1.compareTo(date2);
                        if (result == 0) {
                            result = time1.compareTo(time2);
                        }

                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    return result;
                }
            });
            MainActivity.taskList.clear();
            MainActivity.taskList = sortingList;
        }
        Log.d("demo", "Sorted list is :" + MainActivity.taskList.size());
        for (Task tsk : MainActivity.taskList) {
            Log.d("demo", "displaying the sorted list" + tsk.getTaskDate() + tsk.getTaskTime() + tsk.getTaskTitle());
        }
    }

    private void updateTaskNumbers(LinkedList<Task> taskList) {
        for (int i = 0; i < taskList.size(); i++) {
            taskList.get(i).setTaskNumber(i);
        }
    }


    private boolean validateFields() {
        boolean validTitle = false;
        boolean validDate = false;
        boolean validTime = false;
        if (title.getText().equals("") || title.getText().length() == 0) {
            Toast.makeText(getApplicationContext(), "Enter title", Toast.LENGTH_SHORT).show();
        } else {
            validTitle = true;
        }
        if (dateText.getText().equals("") || dateText.getText().length() == 0) {
            Toast.makeText(getApplicationContext(), "Enter valid date", Toast.LENGTH_SHORT).show();
        } else {
            validDate = true;
        }
        if (timeText.getText().equals("") || timeText.getText().length() == 0) {
            Toast.makeText(getApplicationContext(), "Enter valid time", Toast.LENGTH_SHORT).show();
        } else {
            validTime = true;
        }
        if (validTitle && validDate && validTime) {
            return true;
        } else {
            return false;
        }

    }

    private void createTimeDialog() {
        // Use the current time as the default values for the picker
        final Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);

        timePickerDialog = new TimePickerDialog(CreateTaskActivity.this, R.style.Theme_AppCompat_DayNight_Dialog, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hours, int minutes) {
                c.set(Calendar.HOUR, hours);
                c.set(Calendar.MINUTE, minutes);
                timeText.setText(timeFormatter.format(c.getTime()));
            }
        }, hour, minute, true);

    }
}
