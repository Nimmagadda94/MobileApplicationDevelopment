package hw2_group6.first.com.hw2_group6;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {

    public static final int CREATE_TASK_CODE = 100;
    public static final int EDIT_TASK_CODE = 200;
    static String CREATE_TASK = "createTask";
    static String EDIT_TASK = "editTask";

    public static final int FIRST_ELEMENT = 0;

    Task newTask = null;

    static LinkedList<Task> taskList = new LinkedList<Task>();

    TextView taskNumber;
    TextView taskTitle;
    TextView taskDate;
    TextView taskTime;
    TextView taskPriority;
    TextView taskPage;
    TextView taskStartPage;
    TextView taskOf;
    TextView taskEndPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.to_do_img);
        setTitle(R.string.app_name);

        findViewByIds();

        findViewById(R.id.btnAdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent createIntent = new Intent(MainActivity.this, CreateTaskActivity.class);
                startActivityForResult(createIntent, CREATE_TASK_CODE);
            }
        });
        // Go to first task image clicked
        findViewById(R.id.imgFirst).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo", "First data image clicked");
                findViewByIds();
                if (taskList.size() > 0) {//if linked list greater than 0 pick the first element
                    newTask = new Task();
                    newTask = taskList.getFirst();
                    Log.d("demo", "First element record number :" + newTask.getTaskNumber());
                    displayTaskDetails(newTask);
                } else {
                    Toast.makeText(getApplicationContext(), "Task List empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
        // Go to last task image clicked
        findViewById(R.id.imgLast).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo", "Last data image clicked");
                findViewByIds();
                int n = taskList.size();
                newTask = new Task();
                if (n > 1) {
                    newTask = taskList.getLast();//read the last element in the list
                    Log.d("demo", "Last element record number :" + newTask.getTaskNumber());
                    displayTaskDetails(newTask);
                } else if (n == 1) {//if only one record exists then that is the last element in the list
                    newTask = taskList.getFirst();
                    Log.d("demo", "Last element record number :" + newTask.getTaskNumber());
                    displayTaskDetails(newTask);
                } else {
                    Toast.makeText(getApplicationContext(), "Task List empty", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //previous image clicked.
        findViewById(R.id.imgPrevious).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Log.d("demo", "Previous image clicked");
                findViewByIds();
                int n = taskList.size();
                newTask = new Task();
                int currentPage = Integer.parseInt(taskStartPage.getText().toString());
                Log.d("demo", "Current page is :" + currentPage);
                if (currentPage == 1) {
                    Toast.makeText(getApplicationContext(), "Current Task is first task", Toast.LENGTH_SHORT).show();
                } else {
                    displayTaskDetails(taskList.get(currentPage - 2));
                }
            }
        });

        //next image clicked
        findViewById(R.id.imgNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo", "Next image clicked");
                findViewByIds();
                int n = taskList.size();
                newTask = new Task();
                int currentPage = Integer.parseInt(taskStartPage.getText().toString());
                Log.d("demo", "Current page is :" + currentPage);
                if (currentPage == taskList.size()) {
                    Toast.makeText(getApplicationContext(), "Current Task is the last task", Toast.LENGTH_SHORT).show();
                } else {
                    displayTaskDetails(taskList.get(currentPage));
                }
            }
        });

        //Edit Current task image clicked
        findViewById(R.id.imgEdit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo", "Edit image clicked...");
                findViewByIds();
                newTask = new Task();
                newTask.setTaskNumber(Integer.parseInt(taskNumber.getText().toString()));
                newTask.setTaskTitle(taskTitle.getText().toString());
                newTask.setTaskDate(taskDate.getText().toString());
                newTask.setTaskTime(taskTime.getText().toString());
                newTask.setTaskPriority(taskPriority.getText().toString());
                Intent editIntent = new Intent(MainActivity.this, EditActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("value", newTask);
                editIntent.putExtra(MainActivity.EDIT_TASK, bundle);
                startActivityForResult(editIntent, EDIT_TASK_CODE);
            }
        });

        //delete current task
        findViewById(R.id.imgDelete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo", "Delete image clicked...");
                //record number available in invisible text view. Use that for deletion.
                taskNumber = (TextView) findViewById(R.id.txtTaskNumber);
                int deleteRecordNumber = Integer.parseInt(taskNumber.getText().toString());
                for (Task deleteTask : taskList) {
                    Log.d("demo", "Does record ids match?:::" + deleteRecordNumber + deleteTask.getTaskNumber());
                    if (deleteTask.getTaskNumber() == deleteRecordNumber) {
                        Log.d("demo", "Record number matched:" + deleteRecordNumber);
                        taskList.remove(deleteRecordNumber);
                        updateTaskNumbers(taskList);
                        Log.d("demo", "After removing record task list size is :" + taskList.size());
                        break;
                    }
                }
                //After deleting the record display the first task on the screen.
                if (taskList.size() > 0) {//if linked list greater than 0 pick the first element
                    newTask = new Task();
                    newTask = taskList.getFirst();
                    Log.d("demo", "First element record number :" + newTask.getTaskNumber());
                    displayTaskDetails(newTask);
                }
            }
        });
    }

    private void updateTaskNumbers(LinkedList<Task> taskList) {
        for (int i = 0; i < taskList.size(); i++) {
            taskList.get(i).setTaskNumber(i);
        }
    }

    private void findViewByIds() {
        //keep task number invisible in the layout.Will be useful for edit and delete functionality.
        taskNumber = (TextView) findViewById(R.id.txtTaskNumber);
        taskTitle = (TextView) findViewById(R.id.txtTitle);
        taskDate = (TextView) findViewById(R.id.txtDate);
        taskTime = (TextView) findViewById(R.id.txtTime);
        taskPriority = (TextView) findViewById(R.id.txtPriority);
        taskPage = (TextView) findViewById(R.id.txtPage);
        taskStartPage = (TextView) findViewById(R.id.txtStartPage);
        taskOf = (TextView) findViewById(R.id.txtOf);
        taskEndPage = (TextView) findViewById(R.id.txtEndPage);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CREATE_TASK_CODE) {
            if (resultCode == RESULT_OK) {
                Task newTask = new Task();
                newTask = (Task) data.getExtras().getSerializable(CREATE_TASK);
                findViewByIds();
                displayTaskDetails((Task) taskList.get(newTask.getTaskNumber()));
                Log.d("demo", "Task List Total count : " + taskList.size());
            }
        } else if (requestCode == EDIT_TASK_CODE) {
            if (resultCode == RESULT_OK) {
                Task newTask = new Task();
                newTask = (Task) data.getExtras().getSerializable(EDIT_TASK);
                findViewByIds();
                displayTaskDetails((Task) taskList.get(newTask.getTaskNumber()));
                Log.d("demo", "Task Edited. List size to not increase : " + taskList.size());
            }
        } else {
            //do nothing
        }
    }

    private void displayTaskDetails(Task newTask) {
        taskNumber.setText(String.valueOf(newTask.getTaskNumber()));
        taskTitle.setText(newTask.getTaskTitle().toString());
        taskDate.setText(newTask.getTaskDate().toString());
        taskTime.setText(newTask.getTaskTime().toString());
        taskPriority.setText(newTask.getTaskPriority().toString());
        taskPage.setVisibility(View.VISIBLE);
        taskStartPage.setVisibility(View.VISIBLE);
        taskOf.setVisibility(View.VISIBLE);
        taskEndPage.setVisibility(View.VISIBLE);
        updatePageInfo(newTask);
    }

    private void updatePageInfo(Task newTask) {
        int startPage = newTask.getTaskNumber() + 1;
        int endPage = taskList.size();
        taskStartPage.setText(String.valueOf(startPage));
        taskEndPage.setText(String.valueOf(endPage));
    }
}
