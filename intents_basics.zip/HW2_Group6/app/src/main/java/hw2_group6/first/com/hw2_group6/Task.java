package hw2_group6.first.com.hw2_group6;

import java.io.Serializable;

public class Task implements Serializable {

    private int taskNumber;
    private String taskTitle;
    private String taskDate;
    private String taskTime;
    private String taskPriority;

    public Task(){

    }

    public Task(String taskTitle, String taskDate, String taskTime) {
        this.taskTitle = taskTitle;
        this.taskDate = taskDate;
        this.taskTime = taskTime;
    }

    public int getTaskNumber() {
        return taskNumber;
    }

    public void setTaskNumber(int taskNumber) {
        this.taskNumber = taskNumber;
    }

    public String getTaskTitle() {
        return taskTitle;
    }

    public void setTaskTitle(String taskTitle) {
        this.taskTitle = taskTitle;
    }

    public String getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(String taskDate) {
        this.taskDate = taskDate;
    }

    public String getTaskTime() {
        return taskTime;
    }

    public void setTaskTime(String taskTime) {
        this.taskTime = taskTime;
    }

    public String getTaskPriority() {
        return taskPriority;
    }

    public void setTaskPriority(String taskPriority) {
        this.taskPriority = taskPriority;
    }
}
