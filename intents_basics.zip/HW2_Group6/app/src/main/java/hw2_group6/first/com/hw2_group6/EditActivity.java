package hw2_group6.first.com.hw2_group6;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedList;
import java.util.Locale;

public class EditActivity extends AppCompatActivity {

    private DatePickerDialog datePickerDialog;
    private TimePickerDialog timePickerDialog;

    EditText taskTitle;
    EditText taskDate;
    EditText taskTime;
    RadioGroup taskPriority;
    RadioButton rb;

    private Calendar newCalendar = Calendar.getInstance();
    private SimpleDateFormat dateFormatter = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
    ;;
    private SimpleDateFormat timeFormatter = new SimpleDateFormat("hh:mm a", Locale.US);

    int taskNumber = 0;
    Task editTask = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.to_do_img);
        setTitle(R.string.edit_task_name);

        taskDate = findViewById(R.id.txtDate);
        taskDate.setOnKeyListener(null);
        taskDate.setKeyListener(null);
        taskDate.requestFocus();
        final DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                newCalendar.set(Calendar.YEAR, year);
                newCalendar.set(Calendar.MONTH, monthOfYear);
                newCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                taskDate.setText(dateFormatter.format(newCalendar.getTime()));
            }
        };
        taskDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(EditActivity.this, dateSetListener, newCalendar.get(Calendar.YEAR),
                        newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        taskTime = findViewById(R.id.txtTime);
        taskTime.setOnKeyListener(null);
        taskTime.setKeyListener(null);
        taskTime.setInputType(InputType.TYPE_NULL);
        taskTime.requestFocus();
        taskTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo", "Time dialog to show up");
                createTimeDialog();
                timePickerDialog.setTitle(R.string.time_dialog_title);
                timePickerDialog.show();
            }
        });


        if (getIntent() != null && getIntent().getExtras() != null) {
            editTask = new Task();
            if (getIntent().getExtras().getBundle(MainActivity.EDIT_TASK) != null) {
                editTask = (Task) getIntent().getExtras().getBundle(MainActivity.EDIT_TASK).getSerializable("value");
                findViewByIds();
                taskTitle.setText(editTask.getTaskTitle());
                taskDate.setText(editTask.getTaskDate());
                taskTime.setText(editTask.getTaskTime());
                switch (editTask.getTaskPriority()) {
                    case "High":
                        ((RadioButton) findViewById(R.id.radioHigh)).setChecked(true);
                        break;
                    case "Medium":
                        ((RadioButton) findViewById(R.id.radioMedium)).setChecked(true);
                        break;
                    case "Low":
                        ((RadioButton) findViewById(R.id.radioLow)).setChecked(true);
                        break;
                }
            }
        }

        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isValid = validateFields();
                if (isValid) {
                    taskPriority = findViewById(R.id.radioGroup);
                    rb = (RadioButton) findViewById(taskPriority.getCheckedRadioButtonId());
                    editTask.setTaskTitle(taskTitle.getText().toString());
                    editTask.setTaskDate(taskDate.getText().toString());
                    editTask.setTaskTime(taskTime.getText().toString());
                    editTask.setTaskPriority(rb.getText().toString());
                    MainActivity.taskList.set(editTask.getTaskNumber(), editTask);
                    sortTaskList(MainActivity.taskList);
                    updateTaskNumbers(MainActivity.taskList);
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra(MainActivity.EDIT_TASK, editTask);
                    setResult(RESULT_OK, resultIntent);
                    finish();

                }

            }
        });
    }

    private boolean validateFields() {
        boolean validTitle = false;
        boolean validDate = false;
        boolean validTime = false;
        if (taskTitle.getText().equals("") || taskTitle.getText().length() == 0) {
            Toast.makeText(getApplicationContext(), "Enter title", Toast.LENGTH_SHORT).show();
        } else {
            validTitle = true;
        }
        if (taskDate.getText().equals("") || taskDate.getText().length() == 0) {
            Toast.makeText(getApplicationContext(), "Enter valid date", Toast.LENGTH_SHORT).show();
        } else {
            validDate = true;
        }
        if (taskTime.getText().equals("") || taskTime.getText().length() == 0) {
            Toast.makeText(getApplicationContext(), "Enter valid time", Toast.LENGTH_SHORT).show();
        } else {
            validTime = true;
        }
        if (validTitle && validDate && validTime) {
            return true;
        } else {
            return false;
        }

    }


    private void updateTaskNumbers(LinkedList<Task> taskList) {
        for (int i = 0; i < taskList.size(); i++) {
            taskList.get(i).setTaskNumber(i);
        }
    }

    private void sortTaskList(LinkedList<Task> taskList) {
        LinkedList<Task> sortingList = new LinkedList<>(MainActivity.taskList);
        Log.d("demo", "Sorting list is : " + sortingList.size());
        Collections.sort(sortingList, new Comparator<Task>() {
            @Override
            public int compare(Task task1, Task task2) {
                int result = 0;
                SimpleDateFormat sdf = new SimpleDateFormat("mm-dd-yyyy");
                SimpleDateFormat format = new SimpleDateFormat("HH:mm");
                try {
                    Date date1 = sdf.parse(task1.getTaskDate());
                    Date date2 = sdf.parse(task2.getTaskDate());
                    Date time1 = format.parse(task1.getTaskTime());
                    Date time2 = format.parse(task2.getTaskTime());
                    Log.d("demo", "both the date values : " + date1 + " " + date2);
                    result = date1.compareTo(date2);
                    if (result == 0) {
                        result = time1.compareTo(time2);
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                return result;
            }
        });
        MainActivity.taskList.clear();
        MainActivity.taskList = sortingList;
    }

    private void createTimeDialog() {
        // Use the current time as the default values for the picker
        final Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);

        timePickerDialog = new TimePickerDialog(EditActivity.this, R.style.Theme_AppCompat_DayNight_Dialog, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hours, int minutes) {
                c.set(Calendar.HOUR, hours);
                c.set(Calendar.MINUTE, minutes);
                taskTime.setText(timeFormatter.format(c.getTime()));
            }
        }, hour, minute, true);
    }

    private void findViewByIds() {
        taskTitle = (EditText) findViewById(R.id.txtTitle);
        taskDate = (EditText) findViewById(R.id.txtDate);
        taskTime = (EditText) findViewById(R.id.txtTime);
        taskPriority = (RadioGroup) findViewById(R.id.radioGroup);
    }

}
