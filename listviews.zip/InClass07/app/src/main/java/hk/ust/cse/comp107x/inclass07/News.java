package hk.ust.cse.comp107x.inclass07;

import java.io.Serializable;

/**
 * Created by vasanthinimmagadda on 2/26/18.
 */

public class News implements Serializable{
    public String title;
    public String description;
    public String urlToImage;
    public String publishedAt;

    public News() {
    }

    @Override
    public String toString() {
        return "News{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", urlToImage='" + urlToImage + '\'' +
                ", publishedAt='" + publishedAt + '\'' +
                '}';
    }
}
