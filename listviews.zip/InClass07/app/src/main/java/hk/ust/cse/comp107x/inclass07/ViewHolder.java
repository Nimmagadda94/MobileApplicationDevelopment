package hk.ust.cse.comp107x.inclass07;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by vasanthinimmagadda on 2/26/18.
 */

public class ViewHolder {
    ImageView image;
    TextView title;
    TextView pubdate;
}
