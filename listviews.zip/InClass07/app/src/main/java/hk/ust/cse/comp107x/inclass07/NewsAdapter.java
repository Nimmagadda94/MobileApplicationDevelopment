package hk.ust.cse.comp107x.inclass07;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.List;

/**
 * Created by vasanthinimmagadda on 2/26/18.
 */

public class NewsAdapter extends ArrayAdapter {
    public NewsAdapter(@NonNull Context context, int resource, @NonNull List objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;
        News news = (News) getItem(position);
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.news_layout, parent,false);
            viewHolder = new ViewHolder();
            viewHolder.image = (ImageView) convertView.findViewById(R.id.imageView);
            viewHolder.title = (TextView) convertView.findViewById(R.id.textView);
            viewHolder.pubdate = (TextView) convertView.findViewById(R.id.textView2);
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        Picasso.with(getContext())
                .load(news.urlToImage)
                .resize(250, 250).centerCrop()
                .into(viewHolder.image);
        viewHolder.title.setText(news.title);
        viewHolder.pubdate.setText(news.publishedAt);
        return convertView;
    }
}
