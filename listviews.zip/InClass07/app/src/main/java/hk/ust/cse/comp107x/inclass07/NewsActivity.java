package hk.ust.cse.comp107x.inclass07;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class NewsActivity extends AppCompatActivity implements NewsAsync.Idata{

    ArrayList<News> news = new ArrayList<>();
    Activity activity;
    ProgressDialog pd;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        Intent intent = getIntent();
        String cat = intent.getStringExtra("categoryselected");
        setTitle(cat);

        String url = "https://newsapi.org/v2/top-headlines?country=us&category="+cat+"&apiKey=a5ac536291404056a02b5b385b0ac9a3";

        if(isConnected()){
            pd = new ProgressDialog(NewsActivity.this);
            pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pd.getProgress();
            pd.show();
            pd.setCancelable(false);
            new NewsAsync(NewsActivity.this).execute(url);
        }else{
            Toast.makeText(this, "There is no internet connection and do not attempt to send the HTTP request.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    @Override
    public void handledata(ArrayList<News> data) {
        news = data;
        pd.dismiss();
        if(news!=null) {
            listView = (ListView) findViewById(R.id.listview);
            NewsAdapter adapter = new NewsAdapter(this, R.layout.news_layout, news);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(NewsActivity.this, DisplayActivity.class);
                    intent.putExtra("newsselected", news.get(position));
                    startActivity(intent);
                }
            });
        }else {
            Toast.makeText(this, "No News Found", Toast.LENGTH_SHORT).show();
        }
    }
}
