package hk.ust.cse.comp107x.inclass07;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        Intent intent = getIntent();
        TextView title = (TextView) findViewById(R.id.textView3);
        TextView description = (TextView) findViewById(R.id.textView5);
        TextView pubdate = (TextView) findViewById(R.id.textView4);
        ImageView imageView = (ImageView) findViewById(R.id.imageView3);

        if(getIntent()!=null && getIntent().getExtras()!=null){
            News displayNews = (News)getIntent().getExtras().getSerializable("newsselected");
            title.setText(displayNews.title);
            pubdate.setText(displayNews.publishedAt);
            if(displayNews.description==null || displayNews.description.equals("null")){
                description.setText(" ");
            }else{
                description.setText(displayNews.description);
            }
            if(displayNews.urlToImage!=null){
                Picasso.with(getApplicationContext())
                        .load(displayNews.urlToImage)
                        .resize(1000, 500)
                        .centerCrop()
                        .into(imageView);
            }
        }
    }
}
