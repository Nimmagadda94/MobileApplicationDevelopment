package hk.ust.cse.comp107x.inclass07;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Created by vasanthinimmagadda on 2/26/18.
 */

public class NewsAsync extends AsyncTask<String, Integer, ArrayList<News>>{

    Idata data;

    public NewsAsync(Idata data) {
        this.data = data;
    }

    public static interface Idata{
        public void handledata(ArrayList<News> data);
    }

    @Override
    protected ArrayList<News> doInBackground(String... strings) {
        StringBuilder stringBuilder = new StringBuilder();
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        String str = null;
        ArrayList<News> result = new ArrayList<>();
        try {
            URL url = new URL(strings[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = "";
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                str = stringBuilder.toString();

                JSONObject root = new JSONObject(str);
                JSONArray news = root.getJSONArray("articles");
                for (int i=0;i<news.length();i++) {
                    JSONObject personJson = news.getJSONObject(i);
                    News news1 = new News();
                    news1.title = personJson.getString("title");
                    news1.description = personJson.getString("description");
                    news1.urlToImage = personJson.getString("urlToImage");
                    news1.publishedAt = personJson.getString("publishedAt");
                    result.add(news1);
                }
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return result;
    }

    @Override
    protected void onPostExecute(ArrayList<News> news) {
        data.handledata(news);
    }
}
