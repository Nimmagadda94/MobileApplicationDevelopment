package hk.ust.cse.comp107x.midterm;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by vasanthinimmagadda on 3/12/18.
 */

public class GetAsync extends AsyncTask<String, Integer, ArrayList<Apps>> {

    @Override
    protected ArrayList doInBackground(String... strings) {
        HttpURLConnection connection = null;
        ArrayList<Apps> result = new ArrayList<>();
        try {
            URL url = new URL(strings[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                JSONObject root = new JSONObject(json);
                JSONObject feed = root.getJSONObject("feed");
                JSONArray results = feed.getJSONArray("results");
                for (int i=0;i<results.length();i++) {
                    JSONObject appJson = results.getJSONObject(i);
                    Apps app = new Apps();
                    app.name = appJson.getString("name");
                    app.artistName = appJson.getString("artistName");
                    app.releaseDate = appJson.getString("releaseDate");
                    app.copyright = appJson.getString("copyright");
                    app.artworkUrl100 = appJson.getString("artworkUrl100");

                    JSONArray genreJson = appJson.getJSONArray("genres");
                    for(int j=0; j<genreJson.length();j++){
                        JSONObject genres = genreJson.getJSONObject(j);
                        Genres genre = new Genres();
                        genre.name = genres.getString("name");
                        app.genres.add(genre);
                    }
                    result.add(app);
                }
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        Log.d("demo", result.toString());
        return result;

    }

    @Override
    protected void onPostExecute(ArrayList arrayList) {
        idata.handledata(arrayList);
    }

    public interface Idata{
        public void handledata(ArrayList<Apps> data);
    }
    Idata idata;

    public GetAsync(Idata idata) {
        this.idata = idata;
    }
}
