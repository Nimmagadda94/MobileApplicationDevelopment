package hk.ust.cse.comp107x.midterm;

import java.io.Serializable;

/**
 * Created by vasanthinimmagadda on 3/12/18.
 */

public class Genres implements Serializable{
    public String name;
}
