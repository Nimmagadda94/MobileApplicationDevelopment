package hk.ust.cse.comp107x.midterm;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_details);

        ImageView imageView = (ImageView) findViewById(R.id.imageView2);
        TextView nameview = (TextView) findViewById(R.id.textView7);
        TextView dateview = (TextView) findViewById(R.id.textView8);
        TextView genreview = (TextView) findViewById(R.id.textView9);
        TextView artistview = (TextView) findViewById(R.id.textView10);
        TextView copyrightview = (TextView) findViewById(R.id.textView11);

        Intent intent = getIntent();
        if(getIntent()!=null && getIntent().getExtras()!=null){
            Apps app = (Apps) getIntent().getExtras().getSerializable("selectedapp");
            if(app.artworkUrl100!=null){
                Picasso.with(getApplicationContext())
                        .load(app.artworkUrl100)
                        .resize(700, 700)
                        .centerCrop()
                        .into(imageView);
            }
            nameview.setText(app.name);
            dateview.setText(app.releaseDate);
            List<String> g = new ArrayList<>();
            for(int i=0;i<app.genres.size();i++) {
                g.add(app.genres.get(i).name);
            }
            Set<String> list = new HashSet<String>(g);
            final String[] contactListNames = (String[]) list.toArray(new String[list.size()]);
            Arrays.sort(contactListNames);
            String s = "";
            for (int i = 0; i <contactListNames.length; i++){
                if(i==contactListNames.length-1){
                    s = s.concat(contactListNames[i]);
                }else {
                    s = s.concat(contactListNames[i] + ", ");
                }
            }
            Log.d("demo", s);
            genreview.setText(s);
            artistview.setText(app.artistName);
            copyrightview.setText(app.copyright);
        }
        else {
            Toast.makeText(this, "No data has been passed", Toast.LENGTH_LONG).show();
        }
    }
}
