package hk.ust.cse.comp107x.midterm;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ListviewAdapter extends ArrayAdapter {


    public ListviewAdapter(@NonNull Context context, int resource, @NonNull List objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;
        Apps app = (Apps) getItem(position);
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_listview_adapter, parent,false);
            viewHolder = new ViewHolder();
            viewHolder.imageView = (ImageView) convertView.findViewById(R.id.imageView);
            viewHolder.textViewname = (TextView) convertView.findViewById(R.id.textView3);
            viewHolder.textViewartist = (TextView) convertView.findViewById(R.id.textView4);
            viewHolder.textViewdate = (TextView) convertView.findViewById(R.id.textView5);
            viewHolder.textViewgenres = (TextView) convertView.findViewById(R.id.textView6);
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        Picasso.with(getContext())
                .load(app.artworkUrl100)
                .resize(250, 250).centerCrop()
                .into(viewHolder.imageView);
        viewHolder.textViewname.setText(app.name);
        viewHolder.textViewartist.setText(app.artistName);
        viewHolder.textViewdate.setText(app.releaseDate);
        List<String> g = new ArrayList<>();
        for(int i=0;i<app.genres.size();i++) {
            g.add(app.genres.get(i).name);
        }
        Set<String> list = new HashSet<String>(g);
        final String[] contactListNames = (String[]) list.toArray(new String[list.size()]);
        Arrays.sort(contactListNames);
        String s = "";
        for (int i = 0; i <contactListNames.length; i++){
            if(i==contactListNames.length-1){
                s = s.concat(contactListNames[i]);
            }else {
                s = s.concat(contactListNames[i] + ", ");
            }
        }
        viewHolder.textViewgenres.setText(s);
        return convertView;
    }
}
