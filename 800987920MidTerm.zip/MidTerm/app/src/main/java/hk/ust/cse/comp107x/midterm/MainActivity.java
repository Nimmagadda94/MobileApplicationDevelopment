package hk.ust.cse.comp107x.midterm;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatSpinner;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements GetAsync.Idata{

    ProgressDialog pd;
    AlertDialog.Builder builder;
    ArrayList<Apps> apps = new ArrayList<>();
    ArrayList<Apps> getApps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //https://rss.itunes.apple.com/api/v1/us/ios-apps/top-grossing/all/50/explicit.json

        Button filterbutton = (Button) findViewById(R.id.button);
        filterbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<String> supplierNames1 = new ArrayList<String>();
                for(Apps app:apps){
                    for(int i=0; i<app.genres.size();i++){
                        supplierNames1.add(app.genres.get(i).name);
                    }
                }
                Set<String> list = new HashSet<String>(supplierNames1);
                final String[] contactListNames = (String[]) list.toArray(new String[list.size()]);
                Arrays.sort(contactListNames);
                builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Choose Genre");
                builder.setItems(contactListNames, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        TextView textView = (TextView) findViewById(R.id.textView2);
                        String selected = contactListNames[which];
                        textView.setText(selected);
                        ArrayList<Apps> filtered = new ArrayList<>();
                        for(Apps app : apps){
                            for(int i=0;i<app.genres.size();i++){
                                if(app.genres.get(i).name == selected){
                                    filtered.add(app);
                                }
                            }
                        }
                        displaydata(filtered);
                    }
                });
                builder.create().show();
            }
        });

        pd = new ProgressDialog(MainActivity.this);
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.getProgress();
        pd.show();
        new GetAsync(MainActivity.this).execute("https://rss.itunes.apple.com/api/v1/us/ios-apps/top-grossing/all/50/explicit.json");
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    @Override
    public void handledata(ArrayList<Apps> data) {
        apps = data;
        pd.dismiss();
        Log.d("demo", "all apps: " + data.size());
        TextView selectedgenre = (TextView) findViewById(R.id.textView2);
        selectedgenre.setText("All");
        displaydata(apps);
    }

    public void displaydata(ArrayList<Apps> data){
        ListView listView = (ListView) findViewById(R.id.listview);
        getApps = data;
        if(getApps!=null){
            ListviewAdapter adapter = new ListviewAdapter(this, R.layout.activity_listview_adapter, getApps);
            listView.setAdapter(adapter);
        }else {
            Toast.makeText(this, "No data has been retrieved!", Toast.LENGTH_LONG).show();
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, AppDetails.class);
                intent.putExtra("selectedapp", getApps.get(position));
                startActivity(intent);
            }
        });
    }
}
