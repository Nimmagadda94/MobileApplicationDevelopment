package hk.ust.cse.comp107x.midterm;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by vasanthinimmagadda on 3/12/18.
 */

public class Apps implements Serializable{
    public String artistName;
    public String id;
    public String releaseDate;
    public String name;
    public String kind;
    public String copyright;
    public String artistId;
    public String artistUrl;
    public String artworkUrl100;
    public String url;
    public ArrayList<Genres> genres = new ArrayList<>();
}
