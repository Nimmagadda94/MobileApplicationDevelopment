package hk.ust.cse.comp107x.midterm;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by vasanthinimmagadda on 3/12/18.
 */

public class ViewHolder {
    ImageView imageView;
    TextView textViewname;
    TextView textViewartist;
    TextView textViewdate;
    TextView textViewgenres;
}
