package hk.ust.cse.comp107x.inclass08;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class MainFragment extends Fragment {


    public MainFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            onButtonClicked = (OnButtonClicked) context;
        }catch (Exception e){
            Log.d("demo", "onAttach: error ");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    public interface OnButtonClicked{
        public void handletext(Student student);
    }

    OnButtonClicked onButtonClicked;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Main Activity");
        Button button = (Button) getActivity().findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Student student = new Student();
                EditText name = (EditText) getActivity().findViewById(R.id.editText);
                EditText email = (EditText) getActivity().findViewById(R.id.editText2);
                SeekBar seekBar = (SeekBar) getActivity().findViewById(R.id.seekBar);

                boolean deptSelected = true;
                try {
                    RadioGroup rg = (RadioGroup) getActivity().findViewById(R.id.radioGroup);
                    RadioButton dept = (RadioButton) getActivity().findViewById(rg.getCheckedRadioButtonId());
                    student.setDepartment(dept.getText().toString());
                }
                catch (Exception e)
                {
                    deptSelected = false;
                }

                if(name.getText().toString()==null || name.getText().toString().length()==0){
                    Toast.makeText(getContext(), "Enter your name", Toast.LENGTH_SHORT).show();
                }
                else if(email.getText().toString()==null || email.getText().toString().length()==0){
                    Toast.makeText(getContext(), "Enter your Email", Toast.LENGTH_SHORT).show();
                }
                else if(seekBar.getProgress()==0){
                    Toast.makeText(getContext(), "Select your Mood", Toast.LENGTH_SHORT).show();
                }
                else if(!deptSelected) {
                    Toast.makeText(getContext(), "Select your department", Toast.LENGTH_SHORT).show();
                } else {
                    student.setName(name.getText().toString());
                    student.setEmail(email.getText().toString());
                    student.setMood(seekBar.getProgress());
                    onButtonClicked.handletext(student);
                }
            }
        });
    }

}
