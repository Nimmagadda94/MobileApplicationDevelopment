package hk.ust.cse.comp107x.inclass08;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;


public class EditDeptFragment extends Fragment {

    Student student;

    public EditDeptFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        student = (Student) getArguments().getSerializable("student");
        return inflater.inflate(R.layout.fragment_edit_dept, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Edit Dept. Activity");
        switch(student.getDepartment()){
            case "SIS":
                ((RadioButton) getActivity().findViewById(R.id.radioButton)).setChecked(true);
                break;
            case "CS":
                ((RadioButton) getActivity().findViewById(R.id.radioButton2)).setChecked(true);
                break;
            case "BIO":
                ((RadioButton) getActivity().findViewById(R.id.radioButton3)).setChecked(true);
                break;
            case "Others":
                ((RadioButton) getActivity().findViewById(R.id.radioButton4)).setChecked(true);
                break;
        }
        Button button = (Button) getActivity().findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioGroup rg = (RadioGroup) getActivity().findViewById(R.id.radioGroup);
                RadioButton dept = (RadioButton) getActivity().findViewById(rg.getCheckedRadioButtonId());
                student.setDepartment(dept.getText().toString());
                Bundle bundle = new Bundle();
                bundle.putSerializable("student", student);
                DisplayFragment displayFragment = new DisplayFragment();
                displayFragment.setArguments(bundle);
                getFragmentManager().beginTransaction()
                        .replace(R.id.layout, displayFragment, "editdept")
                        .commit();
            }
        });
    }
}
