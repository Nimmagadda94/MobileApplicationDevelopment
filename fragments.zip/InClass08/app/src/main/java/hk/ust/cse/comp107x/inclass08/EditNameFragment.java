package hk.ust.cse.comp107x.inclass08;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class EditNameFragment extends Fragment {

    Student student;

    public EditNameFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        student = (Student) getArguments().getSerializable("student");
        return inflater.inflate(R.layout.fragment_edit_name, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Edit Name Activity");
        EditText name = (EditText) getActivity().findViewById(R.id.editText);
        name.setText(student.getName());
        Button button = (Button) getActivity().findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText name = (EditText) getActivity().findViewById(R.id.editText);
                student.setName(name.getText().toString());
                Bundle bundle = new Bundle();
                bundle.putSerializable("student", student);
                DisplayFragment displayFragment = new DisplayFragment();
                displayFragment.setArguments(bundle);
                getFragmentManager().beginTransaction()
                            .replace(R.id.layout, displayFragment, "editname")
                            .commit();
            }
        });
    }
}
