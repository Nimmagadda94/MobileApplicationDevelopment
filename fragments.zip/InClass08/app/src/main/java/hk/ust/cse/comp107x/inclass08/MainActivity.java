package hk.ust.cse.comp107x.inclass08;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MainFragment.OnButtonClicked{

    //ArrayList<Student> students =  new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.layout, new MainFragment(), "main")
                .commit();
    }

    @Override
    public void handletext(Student student) {
        //Log.d("demo", student.getName().toString());
        //students.add(student);
        if(student!=null){
            Bundle bundle = new Bundle();
            bundle.putSerializable("student", student);
            DisplayFragment displayFragment = new DisplayFragment();
            displayFragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.layout, displayFragment, "display")
                    .addToBackStack(null)
                    .commit();
        }
    }

    @Override
    public void onBackPressed() {
        if(getSupportFragmentManager().getBackStackEntryCount()>0){
            getSupportFragmentManager().popBackStack();
        }else {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.layout, new MainFragment(), "main")
                    .commit();
        }
    }
}
