package hk.ust.cse.comp107x.inclass08;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;


/**
 * A simple {@link Fragment} subclass.
 */
public class DisplayFragment extends Fragment {

    Student student;

    public DisplayFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        student = (Student) getArguments().getSerializable("student");
        //Log.d("demo", student.getName());
        return inflater.inflate(R.layout.fragment_display, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Display Activity");
        final TextView name = (TextView) getActivity().findViewById(R.id.textView8);
        name.setText(student.getName());
        TextView email = (TextView) getActivity().findViewById(R.id.textView9);
        email.setText(student.getEmail());
        TextView dept = (TextView) getActivity().findViewById(R.id.textView10);
        dept.setText(student.getDepartment());
        TextView mood = (TextView) getActivity().findViewById(R.id.textView11);
        mood.setText(student.getMood()+"% Positive");
        ImageView editname = (ImageView) getActivity().findViewById(R.id.editname);
        editname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("student", student);
                EditNameFragment editNameFragment = new EditNameFragment();
                editNameFragment.setArguments(bundle);
                getFragmentManager().beginTransaction()
                            .replace(R.id.layout, editNameFragment, "editname")
                            .addToBackStack("name")
                            .commit();
            }
        });
        ImageView editemail = (ImageView) getActivity().findViewById(R.id.editemail);
        editemail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("student", student);
                EditEmailFragment editEmailFragment = new EditEmailFragment();
                editEmailFragment.setArguments(bundle);
                getFragmentManager().beginTransaction()
                        .replace(R.id.layout, editEmailFragment, "editemail")
                        .addToBackStack(null)
                        .commit();
            }
        });
        ImageView editdept = (ImageView) getActivity().findViewById(R.id.editdep);
        editdept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("student", student);
                EditDeptFragment editDeptFragment = new EditDeptFragment();
                editDeptFragment.setArguments(bundle);
                getFragmentManager().beginTransaction()
                        .replace(R.id.layout, editDeptFragment, "editdept")
                        .addToBackStack(null)
                        .commit();
            }
        });
        ImageView editmood = (ImageView) getActivity().findViewById(R.id.editmood);
        editmood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("student", student);
                EditMoodFragment editMoodFragment = new EditMoodFragment();
                editMoodFragment.setArguments(bundle);
                getFragmentManager().beginTransaction()
                        .replace(R.id.layout, editMoodFragment, "editmood")
                        .addToBackStack(null)
                        .commit();
            }
        });
    }
}
